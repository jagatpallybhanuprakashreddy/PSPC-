#include<stdio.h>
int main()
{
	int a,b,temp;
	printf("enter a and b\n");
	scanf("%d%d",&a,&b);
	temp=a;
	a=b;
	b=temp;
	printf("swap of numbers is=%d,%d",a,b);
}
