#include<stdio.h>
int main()
{
	float a,b;
	float c;
	printf("enter a and b value\n");
	scanf("%f%f",&a,&b);
	c=(a+b)/2;
	printf("average of a and b is=%f",c);
}
