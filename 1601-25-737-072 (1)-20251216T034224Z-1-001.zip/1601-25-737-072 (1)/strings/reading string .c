#include <stdio.h>
int main()
{
	char st[100];
	gets(st);
	puts(st);
	
	return 0;
	
}
